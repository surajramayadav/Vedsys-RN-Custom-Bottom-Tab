import {createSlice} from '@reduxjs/toolkit';

export const loginslice = createSlice({
  name: 'login',
  initialState: {
    isLogged: false,
    coordinates: {
      lat: null,
      lng: null,
    },
    user: [],
    address: [],
  },
  reducers: {
    setIsLogged: (state, action) => {
      state.isLogged = action.payload;
    },

    setCoordinates: (state, action) => {
      state.coordinates = action.payload;
    },

    setAddress: (state, action) => {
      state.address = action.payload;
    },

    setUser: (state, action) => {
      state.user = action.payload;
    },
  },
});

//actions
export const {setIsLogged, setUser, setCoordinates, setAddress} =
  loginslice.actions;

export default loginslice.reducer;
